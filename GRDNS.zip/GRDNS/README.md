# GRDNS
DNS server written in Go using the Redis databases such that speed go stonks.
