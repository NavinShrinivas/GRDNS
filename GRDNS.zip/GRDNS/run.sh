echo "Make sure go toolchains are installed properly"
echo "also make sure you have redis server installed"
redis-cli FLUSHALL
sudo ./GRDNS
